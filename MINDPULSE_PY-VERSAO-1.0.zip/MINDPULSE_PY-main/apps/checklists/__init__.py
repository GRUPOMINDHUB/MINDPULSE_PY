# Checklists App
default_app_config = 'apps.checklists.apps.ChecklistsConfig'

