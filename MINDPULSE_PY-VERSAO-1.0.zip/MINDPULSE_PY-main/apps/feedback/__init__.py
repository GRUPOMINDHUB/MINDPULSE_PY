# Feedback App
default_app_config = 'apps.feedback.apps.FeedbackConfig'

