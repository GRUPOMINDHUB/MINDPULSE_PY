# Trainings App
default_app_config = 'apps.trainings.apps.TrainingsConfig'

