# Mindpulse Django Project

